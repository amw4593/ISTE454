//
//  DrawMailerApp.swift
//  DrawMailer
//
//  Created by gccisadmin on 11/30/23.
//

import SwiftUI

@main
struct DrawMailerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
