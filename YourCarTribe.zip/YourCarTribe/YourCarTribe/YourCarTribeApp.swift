import SwiftUI

@main
struct YourCarTribeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
