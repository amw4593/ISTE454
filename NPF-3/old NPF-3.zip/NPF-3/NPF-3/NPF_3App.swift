//
//  NPF_3App.swift
//  NPF-3
//
//  Created by gccisadmin on 10/26/23.
//

import SwiftUI

@main
struct NPF_3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
