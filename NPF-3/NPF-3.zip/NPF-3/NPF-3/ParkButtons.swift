import SwiftUI
import MapKit


struct ParkButtons: View {
    
    @Binding var searchResults: [MKMapItem]
    @Binding var position: MapCameraPosition
    @Binding var parks: [Park]
    
    var visibleRegion: MKCoordinateRegion?
    
    
    func search(for query:String) {
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = query
        request.resultTypes = .pointOfInterest
        Task {
            let search = MKLocalSearch(request: request)
            let response = try? await search.start()
            searchResults = response?.mapItems ?? []
        }
    }
    
    var body: some View {
        HStack {
            ForEach(parks, id: \.self) { park in
                Button {
                    position = .camera(MapCamera(centerCoordinate: CLLocationCoordinate2D(latitude: park.getLatitude(), longitude: park.getLongitude()), distance: 980, heading: 242, pitch: 60))
                    
                } label: {
                    Label(park.getParkName(), systemImage: "building.columns.circle")
                }
                .buttonStyle(.bordered)
            }
        }
        .labelStyle(.iconOnly)
    }
}
