//
//  SwiftExerciseApp.swift
//  SwiftExercise
//
//  Created by gccisadmin on 11/2/23.
//

import SwiftUI

@main
struct SwiftExerciseApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
